<!DOCTYPE html>
<html>
<head>
    <title>Test Habib Jannata</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- MULAI STYLE CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.css"
        integrity="sha256-pODNVtK3uOhL8FUNWWvFQK0QoQoV3YA9wGGng6mbZ0E=" crossorigin="anonymous" />
</head>
<body>
    
<div class="container">
    <div class="card">
        <div class="card-header text-center">
            <h1>Data Pekerjaan</h1>
            </div>
        <div class="card-body">      
        <a href="javascript:void(0)" class="btn btn-info" id="tombol-tambah">Tambah Data</a> <br><br>
            <table class="table table-bordered table table-striped table-sm" id="data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Pekerjaan</th>
                        <th>Tanggal_lahir</th>
                    </tr>
                </thead>
            </table>
        </div>

        <div class="card-body">   
            <form method="post" class="form-data" id="form-data">  
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label>Filter Tanggal</label>
                            <select name="tanggal" id="tanggal" class="form-control" required="true">
                                <option value="semua">Semua</option>
                                <option value="tanggal_ganjil">Tanggal Ganjil</option>
                                <option value="tanggal_genap">Tanggal Genap</option>
                                <option value="minggu_ganjil">Minggu Ganjil</option>
                                <option value="minggu_genap">Minggu Genap</option>
                            </select>
                        </div>			
                        <div class="form-group">
                            <button type="button" name="simpan" id="simpan" class="btn btn-primary">
                                <i class="fa fa-save"></i> Simpan
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="modal fade" id="tambah-edit-modal" aria-hidden="true">
            <div class="modal-dialog ">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modal-judul"></h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form id="form-tambah-edit" name="form-tambah-edit" class="form-horizontal">
                            <div class="row">
                                <div class="col-sm-12">
                                    <input type="hidden" name="id" id="id">
                                    <div class="form-group">
                                        <label for="name" class="col-sm-12 control-label">Nama</label>
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" id="nama_pegawai" name="nama"
                                                value="" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="name" class="col-sm-12 control-label">Pekerjaan</label>
                                        <div class="col-sm-12">
                                            <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" value=""
                                                required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="name" class="col-sm-12 control-label">Tanggal_lahir</label>
                                        <div class="col-sm-12">
                                            <input type="date" class="form-control" name="tanggal_lahir" id="tanggal_lahir" required value="">
                                        </div>
                                    </div>

                                </div>

                                <div class="col-sm-offset-2 col-sm-12">
                                    <button type="submit" class="btn btn-primary btn-block" id="tombol-simpan"
                                        value="create">Simpan
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                        <div class="modal-footer">
                    </div>
                </div>
            </div>
        </div>

        <div class="footer text-center">
            <h6>Copyright &copy; Habib Jannata <?php echo date('Y') ?></h6>
        </div>
    </div>
</div>

    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>

    <script type="text/javascript" language="javascript"
        src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" language="javascript"
        src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"
        integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.js"
        integrity="sha256-siqh9650JHbYFKyZeTEAhq+3jvkFCG8Iz+MHdr9eKrw=" crossorigin="anonymous"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    load_data();

    $('#simpan').click(function(){
        var tanggal = $('#tanggal').val()
        if(tanggal != ''){
            $('#data-table').DataTable().destroy();
            load_data(tanggal);
        }
    })

    function load_data(tanggal = ''){
        $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(url('/')); ?>",
                type: "GET",
                data: {tanggal: tanggal}
            },
            columns: [
                {data: 'nama', name: 'nama'},
                {data: 'pekerjaan', name: 'pekerjaan'},
                {data: 'tanggal_lahir', name: 'tanggal_lahir'},
            ]
        });
    }

    $('#tombol-tambah').click(function () {
        $('#button-simpan').val("create-post"); 
        $('#id').val(''); 
        $('#form-tambah-edit').trigger("reset"); 
        $('#modal-judul').html("Tambah DataBaru"); 
        $('#tambah-edit-modal').modal('show');
    });

    if ($("#form-tambah-edit").length > 0) {
        $("#form-tambah-edit").validate({
            submitHandler: function (form) {
                var actionType = $('#tombol-simpan').val();
                $('#tombol-simpan').html('Sending..');
                $.ajax({
                    data: $('#form-tambah-edit').serialize(), 
                    url: "<?php echo e(route('home.store')); ?>", 
                    type: "POST",
                    dataType: 'json',
                    success: function (data) {  
                        $('#form-tambah-edit').trigger("reset"); 
                        $('#tambah-edit-modal').modal('hide'); 
                        $('#tombol-simpan').html('Simpan'); 
                        var oTable = $('#data-table').dataTable();
                        oTable.fnDraw(false);
                        iziToast.success({ 
                        title: 'Data Berhasil Disimpan',
                            message: '<?php echo e(Session(' success ')); ?>',
                            position: 'topRight'
                        });
                    },
                    error: function (data) { 
                        console.log('Error:', data);
                        $('#tombol-simpan').html('Simpan');
                    }
                });
            }
        })
    }
</script>



</body>
</html><?php /**PATH C:\xampp\htdocs\testkerja\test_ipay_habib\resources\views/index.blade.php ENDPATH**/ ?>