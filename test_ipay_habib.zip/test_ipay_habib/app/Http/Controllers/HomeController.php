<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;

use App\Models\User;
use DB;
use DataTables;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {  
        if ($request->ajax()){
            if(!empty($request->tanggal)){
                if($request->tanggal == 'tanggal_ganjil'){
                    $data = DB::select('SELECT * FROM users WHERE day(tanggal_lahir)%2 = 1');
                }elseif($request->tanggal == 'tanggal_genap'){
                    $data = DB::select('SELECT * FROM users WHERE day(tanggal_lahir)%2 = 0');
                }elseif($request->tanggal == 'minggu_ganjil'){
                    $data = DB::select('SELECT * FROM users WHERE WEEK(tanggal_lahir)%2 = 1');
                }elseif($request->tanggal == 'minggu_genap'){
                    $data = DB::select('SELECT * FROM users WHERE WEEK(tanggal_lahir)%2 = 0');
                }elseif($request->tanggal == 'semua'){
                    $data = User::select('*');
                }
            }else{
                $data = User::select('*');
            }      
                return DataTables::of($data)->make(true);
        }
        
        return view('index');  
    }   

    public function store(Request $request)
    {
        $data   =   DB::table('users')->insert([
            'id' => Str::uuid(),
            'nama' => $request->nama,
            'pekerjaan' => $request->pekerjaan,
            'tanggal_lahir' => $request->tanggal_lahir
        ]);

        return response()->json($data);
    }
    
}
