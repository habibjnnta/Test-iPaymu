<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use Illuminate\Support\Str;

use App\Models\User;
use DB;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');
        
        for($i = 1; $i <= 50; $i++){
            // insert data ke table user menggunakan Faker
          User::insert([
              'id' => Str::uuid(),
              'name' => $faker->name,
              'pekerjaan' => $faker->jobTitle,
              'tanggal_lahir' => $faker->dateTimeThisCentury()->format('Y-m-d')
          ]);

      }
    }
}
